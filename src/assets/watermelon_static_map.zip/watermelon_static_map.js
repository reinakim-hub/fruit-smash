// Static watermelon pixel-art map for Fruit Smash.
// Original tile map data, designed to be imported by the Watermelon level.

export const WATERMELON_STATIC_ROWS = [
  '....................................',
  '..............ss....................',
  '..............ss....................',
  '.............sss....................',
  '...........gggSSgg..................',
  '.........gggGGSSGGgg................',
  '........ggGGGGSSGGGGg...............',
  '.......gGGGGGGSSGGGGGg..............',
  '......gGGGGGGGSSGGGGGGg.............',
  '.....gGGggGGGGSSGGggGGGg............',
  '....gGGggggGGGSSGggggGGGg...........',
  '....GGgggggGGGSSGgggggGGGG..........',
  '...gGGggggGGGGSSGGGggggGGGg.........',
  '...GGGgggGGGGGSSGGGGgggGGGG.........',
  '..gGGGGGGGGGGGSSGGGGGGGGGGGg........',
  '..GGGGGGGGGGGGSSGGGGGGGGGGGG........',
  '..GGGGGGGGGGGGSSGGGGGGGGGGGG........',
  '..gGGGGGGGGGGGSSGGGGGGGGGGGg........',
  '...GGGGGGGGGGGSSGGGGGGGGGGG.........',
  '....gGGGGGGGGGSSGGGGGGGGGg..........',
  '.....gGGGGGGGGSSGGGGGGGGg....lll....',
  '......gGGGGGGGSSGGGGGGg...lllllll...',
  '.......gGGGGGGSSGGGGg..lllllllllll..',
  '........gGGGGGSSGGg..LLLLLLLLLLLLLL.',
  '.........ggGGGSSg..LFFFFFFFFFFFFFFL.',
  '............gSS...LFFFFFFFFFFFFFFFL.',
  '.............S...LFFFFFFFFFFFFFFFFL.',
  '.................LFFFFFFFFFFFFFFFFL.',
  '................LFFFFfFFFFFFFFFFFFL.',
  '................LFFfFFFFFFFFFFFFFFL.',
  '................LFFFFFFFFFFFFFFFFFL.',
  '.................LFFFFFFFFFFFFFFFL..',
  '.................LLLkkkkkkkkkkkLL...',
  '...................LLLLLLLLLLLL.....',
  '....................................',
  '....................................',
]

export const WATERMELON_STATIC_LEGEND = {
  '.': null,
  G: 'greenDark',
  g: 'greenLight',
  S: 'greenMid',
  l: 'rindGreen',
  L: 'rindCream',
  F: 'flesh',
  f: 'fleshHighlight',
  k: 'seed',
  s: 'stem',
}

export const WATERMELON_STATIC_PALETTE = {
  greenDark: '#1d6b35',
  greenLight: '#8ecf58',
  greenMid: '#b9df77',
  rindGreen: '#7db54e',
  rindCream: '#dce8ad',
  flesh: '#f07d7b',
  fleshHighlight: '#f6b0aa',
  seed: '#3f2418',
  stem: '#8b5a2b',
}

export function buildWatermelonStaticGrid() {
  return WATERMELON_STATIC_ROWS.map((row) =>
    [...row].map((char) => WATERMELON_STATIC_LEGEND[char] ?? null),
  )
}
