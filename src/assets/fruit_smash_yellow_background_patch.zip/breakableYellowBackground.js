// breakableYellowBackground.js
// Fills every empty board cell with a REMOVABLE yellow-gradient tile.
// The diagonal gradient runs from top-left (light) to bottom-right (deep gold).
// Counts are balanced to multiples of 10 so the existing 10/20/30-ammo logic
// can match every background tile exactly.

export const BREAKABLE_BG_KEYS = [
  'bgYellow1',
  'bgYellow2',
  'bgYellow3',
  'bgYellow4',
  'bgYellow5',
]

export const BREAKABLE_BG_PALETTE = {
  bgYellow1: '#FFF0A6',
  bgYellow2: '#FFE074',
  bgYellow3: '#F7C84B',
  bgYellow4: '#E7A936',
  bgYellow5: '#C98224',
}

function countColor(grid, color) {
  let count = 0
  for (const row of grid) {
    for (const cell of row) {
      if (cell === color) count += 1
    }
  }
  return count
}

// Move only cells nearest the next diagonal band.
// This keeps the gradient visually smooth while making every shade count
// divisible by 10.
function balanceBandsToTens(grid) {
  const rows = grid.length
  const cols = grid[0].length
  const maxDiag = Math.max(1, rows + cols - 2)

  for (let i = 0; i < BREAKABLE_BG_KEYS.length - 1; i += 1) {
    const current = BREAKABLE_BG_KEYS[i]
    const next = BREAKABLE_BG_KEYS[i + 1]
    const remainder = countColor(grid, current) % 10
    if (remainder === 0) continue

    const candidates = []

    for (let row = 0; row < rows; row += 1) {
      for (let col = 0; col < cols; col += 1) {
        if (grid[row][col] !== current) continue

        // Higher diagonal progress = closer to the next darker band.
        const progress = (row + col) / maxDiag
        candidates.push({ row, col, progress })
      }
    }

    candidates.sort((a, b) => b.progress - a.progress)

    for (let n = 0; n < remainder; n += 1) {
      const cell = candidates[n]
      if (cell) grid[cell.row][cell.col] = next
    }
  }

  return grid
}

export function fillBreakableYellowBackground(sourceGrid) {
  const grid = sourceGrid.map((row) => [...row])
  const rows = grid.length
  const cols = grid[0].length
  const maxDiag = Math.max(1, rows + cols - 2)

  for (let row = 0; row < rows; row += 1) {
    for (let col = 0; col < cols; col += 1) {
      // Fruit/art tiles stay exactly as they are.
      if (grid[row][col] !== null) continue

      // 0 at top-left -> 1 at bottom-right.
      const t = (row + col) / maxDiag

      // Five clean diagonal bands.
      const band = Math.min(
        BREAKABLE_BG_KEYS.length - 1,
        Math.floor(t * BREAKABLE_BG_KEYS.length),
      )

      grid[row][col] = BREAKABLE_BG_KEYS[band]
    }
  }

  return balanceBandsToTens(grid)
}
